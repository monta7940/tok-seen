<x-admin.alert>
    We recommend BrightData proxies because they are fast, cheap and reliable. <a href="https://bit.ly/brightdataproxy" target="_blank">Buy Now</a>
</x-admin.alert>
