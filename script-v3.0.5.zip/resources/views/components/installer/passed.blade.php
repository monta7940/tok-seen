<x-installer.icon.check-circle class="status passed" />
