<x-installer.icon.x-circle class="status failed" />
