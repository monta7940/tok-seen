<x-admin.layout title="Artisan">

</x-admin.layout>
