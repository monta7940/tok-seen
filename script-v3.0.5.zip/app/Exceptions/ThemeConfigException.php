<?php

namespace App\Exceptions;

use Exception;
use RuntimeException;

class ThemeConfigException extends RuntimeException
{
    //
}
