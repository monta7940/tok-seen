<?php

namespace App\Exceptions;

use RuntimeException;

class ThemeNotFoundException extends RuntimeException
{
    //
}
