<li>
    <a href="{{$href}}" @class(['is-active'=> $active])>@lang($text)</a>
</li>
