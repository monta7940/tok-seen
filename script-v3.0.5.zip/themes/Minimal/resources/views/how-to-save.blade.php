<x-theme::layout>
    <x-slot:title>
        @lang('How to save TikTok video?')
    </x-slot:title>
    <x-theme::splash/>
    <x-theme::section.how-to />
    <x-theme::section.usage />
</x-theme::layout>
